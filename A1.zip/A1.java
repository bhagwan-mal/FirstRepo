class A1 
{

	 int x=10;
	
		{
		System.out.println("In A NSB");
        System.out.println("x:"+x);
		//System.out.println("b:"+b);
		//System.out.println("b:"+B1.b);
        //System.out.println("b:"+B1.getB());
       }
	   A1(){
		   System.out.println("A cons");
		   x=5;
	   }
	}

